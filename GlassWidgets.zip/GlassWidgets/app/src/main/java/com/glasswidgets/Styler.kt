package com.glasswidgets

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.widget.RemoteViews

object Styler {
    val MAIN_L = 0xFF1C1C1E.toInt()
    val MAIN_D = 0xFFFFFFFF.toInt()
    val SUB_L = 0xFF6C6C72.toInt()
    val SUB_D = 0xFFB8B8C0.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val WHITE_SUB = 0xCCFFFFFF.toInt()

    fun system(c: Context) = Prefs.theme(c) == 2

    fun isDark(c: Context): Boolean = when (Prefs.theme(c)) {
        0 -> false
        1 -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    /** Sets an int-valued view property (color) with automatic light/dark switching when possible. */
    fun color(c: Context, v: RemoteViews, id: Int, method: String, lt: Int, dk: Int) {
        if (system(c) && Build.VERSION.SDK_INT >= 34) {
            v.setColorInt(id, method, lt, dk)
        } else {
            v.setInt(id, method, if (isDark(c)) dk else lt)
        }
    }

    fun tint(c: Context, v: RemoteViews, id: Int, lt: Int, dk: Int) {
        if (Build.VERSION.SDK_INT >= 34 && system(c)) {
            v.setColorStateList(id, "setBackgroundTintList", ColorStateList.valueOf(lt), ColorStateList.valueOf(dk))
        } else if (Build.VERSION.SDK_INT >= 31) {
            v.setColorStateList(id, "setBackgroundTintList", ColorStateList.valueOf(if (isDark(c)) dk else lt))
        }
    }

    fun background(c: Context, v: RemoteViews, kind: String) {
        val bg = android.R.id.background
        if (Prefs.blur(c)) {
            val a = Prefs.alpha(c)
            color(c, v, bg, "setBackgroundColor", Color.argb(a, 255, 255, 255), Color.argb(a, 0, 0, 0))
        } else if (kind == "weather") {
            val res = if (system(c)) R.drawable.bg_weather else if (isDark(c)) R.drawable.bg_weather_d else R.drawable.bg_weather_l
            v.setInt(bg, "setBackgroundResource", res)
        } else {
            color(c, v, bg, "setBackgroundColor", 0xFFF2F2F7.toInt(), 0xFF1F2030.toInt())
        }
    }

    fun text(c: Context, v: RemoteViews, kind: String, main: IntArray, sub: IntArray) {
        val white = kind == "weather" && !Prefs.blur(c)
        val ml = if (white) WHITE else MAIN_L
        val md = if (white) WHITE else MAIN_D
        val sl = if (white) WHITE_SUB else SUB_L
        val sd = if (white) WHITE_SUB else SUB_D
        for (id in main) color(c, v, id, "setTextColor", ml, md)
        for (id in sub) color(c, v, id, "setTextColor", sl, sd)
    }

    fun icon(c: Context, v: RemoteViews, id: Int, kind: String) {
        val white = kind == "weather" && !Prefs.blur(c)
        color(c, v, id, "setColorFilter", if (white) WHITE_SUB else SUB_L, if (white) WHITE_SUB else SUB_D)
    }
}
