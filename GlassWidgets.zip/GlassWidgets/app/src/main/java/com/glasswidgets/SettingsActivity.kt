package com.glasswidgets

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.health.connect.client.PermissionController
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class SettingsActivity : ComponentActivity() {
    private lateinit var healthStatus: TextView
    private lateinit var calStatus: TextView
    private lateinit var cityLabel: TextView

    private val bgLauncher = registerForActivityResult(PermissionController.createRequestPermissionResultContract()) {
        refreshStatus()
        Widgets.updateAll(this)
    }
    private val permLauncher = registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { granted ->
        if (granted.containsAll(HealthData.PERMS)) {
            try { bgLauncher.launch(setOf(HealthData.BG)) } catch (e: Exception) { }
        }
        refreshStatus()
        Widgets.updateAll(this)
    }

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun title(t: String) = TextView(this).apply {
        text = t; textSize = 17f; setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun note(t: String) = TextView(this).apply { text = t; textSize = 13f; alpha = 0.7f }

    private fun field(hint: String, value: String, onChange: (String) -> Unit) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = InputType.TYPE_CLASS_NUMBER
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { onChange(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        isChecked = checked
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, b -> onChange(b); Widgets.updateAll(this@SettingsActivity) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = Prefs.sp(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(40))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply { addView(col); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        setContentView(scroll)

        col.addView(TextView(this).apply { text = "Glass Widgets"; textSize = 26f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        col.addView(note("ویجت‌های Health، Weather و Calendar را از لیست ویجت‌های لانچر (بخش Glass Widgets) اضافه کن."))

        // ----- appearance
        col.addView(title("ظاهر"))
        col.addView(sw("بلر شیشه‌ای (خاموش = پس‌زمینه ساده بدون بلر)", Prefs.blur(this)) { sp.edit().putBoolean("blur", it).apply() })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val names = arrayOf("روشن (Light)", "تیره (Dark)", "مطابق سیستم")
        for (i in 0..2) rg.addView(RadioButton(this).apply { id = 100 + i; text = names[i] })
        rg.check(100 + Prefs.theme(this))
        rg.setOnCheckedChangeListener { _, id -> sp.edit().putInt("theme", id - 100).apply(); Widgets.updateAll(this) }
        col.addView(rg)
        val alphaLabel = note("")
        fun setAlphaLabel(a: Int) { alphaLabel.text = "غلظت رنگ روی بلر: ${a * 100 / 255}٪ (کمتر = شیشه‌ای‌تر)" }
        setAlphaLabel(Prefs.alpha(this))
        col.addView(alphaLabel)
        col.addView(SeekBar(this).apply {
            max = 253
            progress = Prefs.alpha(this@SettingsActivity) - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { setAlphaLabel(p + 1) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    sp.edit().putInt("alpha", (s?.progress ?: 99) + 1).apply()
                    Widgets.updateAll(this@SettingsActivity)
                }
            })
        })

        // ----- health
        col.addView(title("Health"))
        healthStatus = note("")
        col.addView(healthStatus)
        col.addView(Button(this).apply {
            text = "دسترسی به Health Connect"
            setOnClickListener {
                if (!HealthData.available(this@SettingsActivity)) {
                    healthStatus.text = "Health Connect روی گوشی فعال/نصب نیست."
                } else {
                    try { permLauncher.launch(HealthData.PERMS) } catch (e: Exception) { healthStatus.text = "خطا: ${e.message}" }
                }
            }
        })
        col.addView(note("هدف‌ها:"))
        col.addView(field("قدم", Prefs.goalSteps(this).toString()) { sp.edit().putInt("g_steps", it.toIntOrNull() ?: 10000).apply() })
        col.addView(field("دقیقه", Prefs.goalMins(this).toString()) { sp.edit().putInt("g_mins", it.toIntOrNull() ?: 30).apply() })
        col.addView(field("کالری", Prefs.goalKcal(this).toString()) { sp.edit().putInt("g_kcal", it.toIntOrNull() ?: 600).apply() })

        // ----- weather
        col.addView(title("Weather"))
        cityLabel = note("")
        col.addView(cityLabel)
        val cityInput = EditText(this).apply { hint = "نام شهر (انگلیسی)"; inputType = InputType.TYPE_CLASS_TEXT; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.START }
        col.addView(cityInput)
        col.addView(Button(this).apply { text = "جستجوی شهر"; setOnClickListener { searchCity(cityInput.text.toString().trim()) } })
        col.addView(sw("دما به فارنهایت (°F)", Prefs.fahrenheit(this)) { sp.edit().putBoolean("fahrenheit", it).apply() })

        // ----- calendar
        col.addView(title("Calendar"))
        calStatus = note("")
        col.addView(calStatus)
        col.addView(Button(this).apply {
            text = "دسترسی به تقویم"
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 7) }
        })
        col.addView(sw("شروع هفته از دوشنبه", Prefs.weekStart(this) == 1) { sp.edit().putInt("week_start", if (it) 1 else 0).apply() })

        col.addView(Button(this).apply { text = "به‌روزرسانی همه ویجت‌ها"; setOnClickListener { Widgets.updateAll(this@SettingsActivity) } })
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        Widgets.updateAll(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
        Widgets.updateAll(this)
    }

    private fun refreshStatus() {
        val city = Prefs.sp(this).getString("city", "") ?: ""
        cityLabel.text = if (city.isEmpty()) "شهر انتخاب نشده" else "شهر فعلی: $city"
        calStatus.text = if (CalendarData.hasPermission(this)) "تقویم: دسترسی داده شده ✓" else "تقویم: دسترسی داده نشده"
        thread {
            val ok = HealthData.available(this) && HealthData.granted(this)
            runOnUiThread { healthStatus.text = if (ok) "Health Connect: متصل ✓" else "Health Connect: دسترسی داده نشده" }
        }
    }

    private fun searchCity(q: String) {
        if (q.isEmpty()) return
        thread {
            try {
                val u = "https://geocoding-api.open-meteo.com/v1/search?count=6&language=en&format=json&name=" + URLEncoder.encode(q, "UTF-8")
                val con = URL(u).openConnection() as HttpURLConnection
                con.connectTimeout = 8000; con.readTimeout = 8000
                val txt = con.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONObject(txt).optJSONArray("results")
                if (arr == null || arr.length() == 0) {
                    runOnUiThread { cityLabel.text = "شهری پیدا نشد" }
                    return@thread
                }
                val labels = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    labels.add(o.optString("name") + (if (o.has("admin1")) ", " + o.optString("admin1") else "") + ", " + o.optString("country"))
                }
                runOnUiThread {
                    AlertDialog.Builder(this).setItems(labels.toTypedArray()) { _, which ->
                        val o = arr.getJSONObject(which)
                        Prefs.sp(this).edit()
                            .putString("city", o.optString("name"))
                            .putString("lat", o.getDouble("latitude").toString())
                            .putString("lon", o.getDouble("longitude").toString())
                            .remove("wx_raw").apply()
                        refreshStatus()
                        Widgets.updateAll(this)
                    }.show()
                }
            } catch (e: Exception) {
                runOnUiThread { cityLabel.text = "خطا در جستجو (اینترنت را چک کن)" }
            }
        }
    }
}
