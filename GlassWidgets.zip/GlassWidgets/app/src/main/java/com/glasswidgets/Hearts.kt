package com.glasswidgets

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure

object Hearts {
    private fun base(): Path {
        val p = Path()
        p.moveTo(12f, 5.09f)
        p.cubicTo(13.09f, 3.81f, 14.76f, 3f, 16.5f, 3f)
        p.cubicTo(19.58f, 3f, 22f, 5.42f, 22f, 8.5f)
        p.cubicTo(22f, 12.28f, 18.6f, 15.36f, 13.45f, 20.04f)
        p.lineTo(12f, 21.35f)
        p.lineTo(10.55f, 20.04f)
        p.cubicTo(5.4f, 15.36f, 2f, 12.28f, 2f, 8.5f)
        p.cubicTo(2f, 5.42f, 4.42f, 3f, 7.5f, 3f)
        p.cubicTo(9.24f, 3f, 10.91f, 3.81f, 12f, 5.09f)
        p.close()
        return p
    }

    private val COLORS = intArrayOf(0xFF1ED760.toInt(), 0xFF3D9BFF.toInt(), 0xFFFF3D96.toInt())
    private val SCALES = floatArrayOf(0.98f, 0.70f, 0.42f)

    /** Three nested heart rings (steps, minutes, calories) with progress 0..1+. */
    fun rings(size: Int, steps: Float, mins: Float, kcal: Float): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val u = size / 24f
        val prog = floatArrayOf(steps, mins, kcal)
        val basePath = base()
        for (i in 0..2) {
            val m = Matrix()
            m.setScale(SCALES[i], SCALES[i], 12f, 12.2f)
            m.postScale(u, u)
            val path = Path(basePath)
            path.transform(m)
            val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2.4f * u
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                color = COLORS[i]
                alpha = 70
            }
            cv.drawPath(path, track)
            val p = prog[i].coerceIn(0.025f, 1f)
            val pm = PathMeasure(path, false)
            val seg = Path()
            pm.getSegment(0f, pm.length * p, seg, true)
            val pr = Paint(track).apply { alpha = 255 }
            cv.drawPath(seg, pr)
        }
        return bmp
    }
}
