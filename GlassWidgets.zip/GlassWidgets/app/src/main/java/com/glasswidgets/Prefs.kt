package com.glasswidgets

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("gw", Context.MODE_PRIVATE)
    fun blur(c: Context) = sp(c).getBoolean("blur", true)
    fun theme(c: Context) = sp(c).getInt("theme", 2) // 0 light, 1 dark, 2 system
    fun alpha(c: Context) = sp(c).getInt("alpha", 100).coerceIn(1, 254)
    fun goalSteps(c: Context) = sp(c).getInt("g_steps", 10000).coerceAtLeast(1)
    fun goalMins(c: Context) = sp(c).getInt("g_mins", 30).coerceAtLeast(1)
    fun goalKcal(c: Context) = sp(c).getInt("g_kcal", 600).coerceAtLeast(1)
    fun fahrenheit(c: Context) = sp(c).getBoolean("fahrenheit", false)
    fun weekStart(c: Context) = sp(c).getInt("week_start", 0) // 0 Sunday, 1 Monday
}
