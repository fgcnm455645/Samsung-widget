package com.glasswidgets

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.runBlocking
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class HDay(val date: LocalDate, val steps: Long, val mins: Int, val kcal: Int)

object HealthData {
    val PERMS: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class)
    )
    const val BG = "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND"

    private var cache: List<HDay>? = null
    private var cacheTs = 0L

    fun available(c: Context): Boolean =
        HealthConnectClient.getSdkStatus(c) == HealthConnectClient.SDK_AVAILABLE

    fun granted(c: Context): Boolean = try {
        runBlocking {
            HealthConnectClient.getOrCreate(c).permissionController.getGrantedPermissions().containsAll(PERMS)
        }
    } catch (e: Exception) {
        false
    }

    fun weekDays(c: Context): List<LocalDate> {
        val today = LocalDate.now()
        val dow = today.dayOfWeek.value % 7 // Sunday = 0
        val first = today.minusDays(((dow - Prefs.weekStart(c) + 7) % 7).toLong())
        return (0..6).map { first.plusDays(it.toLong()) }
    }

    @Synchronized
    fun week(c: Context): List<HDay> {
        val now = System.currentTimeMillis()
        cache?.let { if (now - cacheTs < 20_000L) return it }
        val days = weekDays(c)
        val empty = days.map { HDay(it, 0L, 0, 0) }
        if (!available(c)) return empty
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        val res: List<HDay> = try {
            runBlocking {
                val cl = HealthConnectClient.getOrCreate(c)
                if (!cl.permissionController.getGrantedPermissions().containsAll(PERMS)) {
                    empty
                } else {
                    val first = days[0]
                    val sessions = cl.readRecords(
                        ReadRecordsRequest(
                            ExerciseSessionRecord::class,
                            TimeRangeFilter.between(
                                first.atStartOfDay(zone).toInstant(),
                                first.plusDays(7).atStartOfDay(zone).toInstant()
                            )
                        )
                    ).records
                    days.map { d ->
                        if (d.isAfter(today)) {
                            HDay(d, 0L, 0, 0)
                        } else {
                            val s = d.atStartOfDay(zone).toInstant()
                            val e = if (d == today) Instant.now() else d.plusDays(1).atStartOfDay(zone).toInstant()
                            val range = TimeRangeFilter.between(s, e)
                            val steps = cl.aggregate(
                                AggregateRequest(metrics = setOf(StepsRecord.COUNT_TOTAL), timeRangeFilter = range)
                            )[StepsRecord.COUNT_TOTAL] ?: 0L
                            val kcal = cl.aggregate(
                                AggregateRequest(metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), timeRangeFilter = range)
                            )[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
                            var mins = 0L
                            for (r in sessions) {
                                if (r.startTime.atZone(zone).toLocalDate() == d) {
                                    mins += Duration.between(r.startTime, r.endTime).toMinutes()
                                }
                            }
                            HDay(d, steps, mins.toInt(), kcal.toInt())
                        }
                    }
                }
            }
        } catch (e: Exception) {
            empty
        }
        cache = res
        cacheTs = now
        return res
    }
}
