package com.glasswidgets

import android.content.Context
import android.widget.RemoteViews

class Weather2x1 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.weather(c, 0)
}

class Weather2x2 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.weather(c, 1)
}

class Weather4x2 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.weather(c, 2)
}

class Health2x1 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.health(c, 0)
}

class Health2x2 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.health(c, 1)
}

class Health4x2 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.health(c, 2)
}

class Calendar2x1 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.calendar(c, 0)
}

class Calendar2x2 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.calendar(c, 1)
}

class Calendar4x2 : BaseWidget() {
    override fun build(c: Context): RemoteViews = Builders.calendar(c, 2)
}

