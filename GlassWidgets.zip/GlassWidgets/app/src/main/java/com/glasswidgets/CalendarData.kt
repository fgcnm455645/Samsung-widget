package com.glasswidgets

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.util.Calendar
import java.util.TimeZone

data class Ev(val title: String, val begin: Long, val end: Long, val allDay: Boolean, val color: Int)

object CalendarData {
    fun hasPermission(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun today(c: Context): List<Ev> {
        if (!hasPermission(c)) return emptyList()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        val end = start + 24L * 3600_000L
        val todayY = cal.get(Calendar.YEAR); val todayD = cal.get(Calendar.DAY_OF_YEAR)
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, start)
        ContentUris.appendId(b, end)
        val out = ArrayList<Ev>()
        try {
            c.contentResolver.query(
                b.build(),
                arrayOf(
                    CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
                    CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.EVENT_COLOR, CalendarContract.Instances.CALENDAR_COLOR
                ),
                null, null, CalendarContract.Instances.BEGIN + " ASC"
            )?.use { q ->
                while (q.moveToNext()) {
                    val allDay = q.getInt(3) == 1
                    val begin = q.getLong(1)
                    if (allDay) {
                        val u = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                        u.timeInMillis = begin
                        if (u.get(Calendar.YEAR) != todayY || u.get(Calendar.DAY_OF_YEAR) != todayD) continue
                    }
                    var col = q.getInt(4)
                    if (col == 0) col = q.getInt(5)
                    if (col == 0) col = 0xFF4CAF50.toInt()
                    out.add(Ev(q.getString(0) ?: "", begin, q.getLong(2), allDay, col or 0xFF000000.toInt()))
                }
            }
        } catch (e: Exception) {
        }
        val now = System.currentTimeMillis()
        if (out.size > 3) {
            val up = out.filter { it.allDay || it.end >= now }
            if (up.isNotEmpty()) return up
        }
        return out
    }
}
