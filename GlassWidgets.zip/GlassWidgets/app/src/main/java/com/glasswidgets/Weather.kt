package com.glasswidgets

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.roundToInt

data class WDay(val label: String, val code: Int, val hi: Int, val lo: Int)
data class WData(
    val temp: Int, val code: Int, val isDay: Boolean, val wind: Double,
    val hi: Int, val lo: Int, val days: List<WDay>, val city: String
)

object Weather {
    fun load(c: Context): WData? {
        val sp = Prefs.sp(c)
        val lat = sp.getString("lat", null) ?: return null
        val lon = sp.getString("lon", null) ?: return null
        val f = Prefs.fahrenheit(c)
        val key = "$lat,$lon,$f"
        var raw = sp.getString("wx_raw", null)
        val ts = sp.getLong("wx_ts", 0L)
        val sameKey = sp.getString("wx_key", "") == key
        val fresh = raw != null && sameKey && System.currentTimeMillis() - ts < 20 * 60_000L
        if (!fresh) {
            try {
                val n = fetch(lat, lon, f)
                JSONObject(n) // validate
                raw = n
                sp.edit().putString("wx_raw", n).putLong("wx_ts", System.currentTimeMillis()).putString("wx_key", key).apply()
            } catch (e: Exception) {
                if (!sameKey) raw = null
            }
        }
        val r = raw ?: return null
        return try { parse(r, sp.getString("city", "") ?: "") } catch (e: Exception) { null }
    }

    private fun fetch(lat: String, lon: String, f: Boolean): String {
        val unit = if (f) "fahrenheit" else "celsius"
        val u = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,weather_code,is_day,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
            "&timezone=auto&forecast_days=5&temperature_unit=$unit&wind_speed_unit=kmh"
        val con = URL(u).openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 8000
        try {
            return con.inputStream.bufferedReader().use { it.readText() }
        } finally {
            con.disconnect()
        }
    }

    private fun parse(raw: String, city: String): WData {
        val j = JSONObject(raw)
        val cur = j.getJSONObject("current")
        val d = j.getJSONObject("daily")
        val times = d.getJSONArray("time")
        val codes = d.getJSONArray("weather_code")
        val mx = d.getJSONArray("temperature_2m_max")
        val mn = d.getJSONArray("temperature_2m_min")
        val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outFmt = SimpleDateFormat("EEE", Locale.ENGLISH)
        val days = (0 until times.length()).map { i ->
            val label = outFmt.format(inFmt.parse(times.getString(i))!!)
            WDay(label, codes.getInt(i), mx.getDouble(i).roundToInt(), mn.getDouble(i).roundToInt())
        }
        return WData(
            cur.getDouble("temperature_2m").roundToInt(), cur.getInt("weather_code"),
            cur.getInt("is_day") == 1, cur.optDouble("wind_speed_10m", 0.0),
            days[0].hi, days[0].lo, days, city
        )
    }

    fun label(code: Int, day: Boolean): String = when (code) {
        0 -> if (day) "Sunny" else "Clear"
        1 -> if (day) "Mostly Sunny" else "Mostly Clear"
        2 -> "Partly Cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        56, 57 -> "Freezing Drizzle"
        61 -> "Light Rain"
        63 -> "Rain"
        65 -> "Heavy Rain"
        66, 67 -> "Freezing Rain"
        71 -> "Light Snow"
        73 -> "Snow"
        75 -> "Heavy Snow"
        77 -> "Snow Grains"
        80, 81, 82 -> "Showers"
        85, 86 -> "Snow Showers"
        95 -> "Thunderstorms"
        96, 99 -> "Thunderstorms, Hail"
        else -> ""
    }

    fun icon(code: Int, day: Boolean, wind: Double = 0.0): Int {
        if (code <= 3 && wind >= 45.0) return R.drawable.wx_fr
        return when (code) {
            0 -> if (day) R.drawable.wx_ok else R.drawable.wx_mo
            1 -> if (day) R.drawable.wx_jd else R.drawable.wx_nk
            2 -> if (day) R.drawable.wx_af else R.drawable.wx_wf
            3 -> if (day) R.drawable.wx_o4 else R.drawable.wx_dx
            45, 48 -> R.drawable.wx_fe
            51, 53, 55, 56, 57 -> R.drawable.wx_a4
            61, 63, 65, 66, 67, 80, 81, 82 -> R.drawable.wx_rv
            71, 73, 75, 77, 85, 86 -> R.drawable.wx_xa
            95 -> if (day) R.drawable.wx_4w else R.drawable.wx_u0
            96, 99 -> R.drawable.wx_to
            else -> R.drawable.wx_af
        }
    }
}
