package com.glasswidgets

object Ids {
    val CELLS = intArrayOf(R.id.cal_c0,R.id.cal_c1,R.id.cal_c2,R.id.cal_c3,R.id.cal_c4,R.id.cal_c5,R.id.cal_c6,R.id.cal_c7,R.id.cal_c8,R.id.cal_c9,R.id.cal_c10,R.id.cal_c11,R.id.cal_c12,R.id.cal_c13,R.id.cal_c14,R.id.cal_c15,R.id.cal_c16,R.id.cal_c17,R.id.cal_c18,R.id.cal_c19,R.id.cal_c20,R.id.cal_c21,R.id.cal_c22,R.id.cal_c23,R.id.cal_c24,R.id.cal_c25,R.id.cal_c26,R.id.cal_c27,R.id.cal_c28,R.id.cal_c29,R.id.cal_c30,R.id.cal_c31,R.id.cal_c32,R.id.cal_c33,R.id.cal_c34,R.id.cal_c35,R.id.cal_c36,R.id.cal_c37,R.id.cal_c38,R.id.cal_c39,R.id.cal_c40,R.id.cal_c41)
    val CAL_H = intArrayOf(R.id.cal_h0,R.id.cal_h1,R.id.cal_h2,R.id.cal_h3,R.id.cal_h4,R.id.cal_h5,R.id.cal_h6)
    val HD_IMG = intArrayOf(R.id.hd0_img,R.id.hd1_img,R.id.hd2_img,R.id.hd3_img,R.id.hd4_img,R.id.hd5_img,R.id.hd6_img)
    val HD_LBL = intArrayOf(R.id.hd0_lbl,R.id.hd1_lbl,R.id.hd2_lbl,R.id.hd3_lbl,R.id.hd4_lbl,R.id.hd5_lbl,R.id.hd6_lbl)
    val F_DAY = intArrayOf(R.id.f0_day,R.id.f1_day,R.id.f2_day,R.id.f3_day)
    val F_I1 = intArrayOf(R.id.f0_i1,R.id.f1_i1,R.id.f2_i1,R.id.f3_i1)
    val F_I2 = intArrayOf(R.id.f0_i2,R.id.f1_i2,R.id.f2_i2,R.id.f3_i2)
    val F_HI = intArrayOf(R.id.f0_hi,R.id.f1_hi,R.id.f2_hi,R.id.f3_hi)
    val F_LO = intArrayOf(R.id.f0_lo,R.id.f1_lo,R.id.f2_lo,R.id.f3_lo)
    val EV_BAR = intArrayOf(R.id.ev0_bar,R.id.ev1_bar,R.id.ev2_bar)
    val EV_TIME = intArrayOf(R.id.ev0_time,R.id.ev1_time,R.id.ev2_time)
    val EV_TITLE = intArrayOf(R.id.ev0_title,R.id.ev1_title,R.id.ev2_title)
}
