Glass Widgets — Health / Weather / Calendar widgets (2x1, 2x2, 4x2) with One UI blur.
Build: upload this folder to a GitHub repo, Actions builds the APK (artifact: GlassWidgets-apk).
