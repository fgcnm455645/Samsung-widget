package com.glasswidgets

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.hypot
import kotlin.math.roundToInt

object Hearts {
    /**
     * Samsung Health heart rings (steps, minutes, calories), traced from the original logo.
     * Progress runs clockwise from the heart's top notch with a start->end color gradient.
     */
    fun rings(width: Int, steps: Float, mins: Float, kcal: Float): Bitmap {
        val s = width / HeartData.W
        val h = (HeartData.H * s).roundToInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val prog = floatArrayOf(steps, mins, kcal)
        val n = HeartData.N
        val sw = HeartData.SW * s
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = sw
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        for (k in 0..2) {
            val xs = HeartData.PX[k]
            val ys = HeartData.PY[k]
            // faded track (full ring)
            val path = Path()
            path.moveTo(xs[0] * s, ys[0] * s)
            for (i in 1 until n) path.lineTo(xs[i] * s, ys[i] * s)
            path.close()
            paint.color = HeartData.TRACK[k]
            paint.alpha = HeartData.TRACK_ALPHA
            cv.drawPath(path, paint)

            // segment lengths
            val seg = FloatArray(n)
            var total = 0f
            for (i in 0 until n) {
                val j = (i + 1) % n
                seg[i] = hypot(xs[j] - xs[i], ys[j] - ys[i])
                total += seg[i]
            }
            val raw = prog[k]
            if (raw <= 0f) {
                // nothing yet: just a round dot at the start of the ring
                val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = HeartData.COL[k][0] }
                cv.drawCircle(xs[0] * s, ys[0] * s, sw / 2f, dot)
                continue
            }
            val p = raw.coerceIn(0.012f, 1f)
            val target = total * p
            val cols = HeartData.COL[k]
            var cum = 0f
            paint.alpha = 255
            for (i in 0 until n) {
                if (cum >= target) break
                val j = (i + 1) % n
                var x2 = xs[j]
                var y2 = ys[j]
                if (cum + seg[i] > target) {
                    val f = (target - cum) / seg[i]
                    x2 = xs[i] + (xs[j] - xs[i]) * f
                    y2 = ys[i] + (ys[j] - ys[i]) * f
                }
                val u = (cum / target).coerceIn(0f, 1f)
                paint.color = cols[(u * (cols.size - 1)).roundToInt()]
                cv.drawLine(xs[i] * s, ys[i] * s, x2 * s, y2 * s, paint)
                cum += seg[i]
            }
        }
        return bmp
    }
}
