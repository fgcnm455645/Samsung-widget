package com.glasswidgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.CalendarContract
import android.view.View
import android.widget.RemoteViews
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.YearMonth
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

abstract class BaseWidget : AppWidgetProvider() {
    abstract fun build(c: Context): RemoteViews

    private fun refresh(c: Context, m: AppWidgetManager, ids: IntArray) {
        val p = goAsync()
        thread {
            try {
                val v = try { build(c) } catch (e: Exception) { null }
                if (v != null) for (id in ids) m.updateAppWidget(id, v)
            } finally {
                p.finish()
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) =
        refresh(context, appWidgetManager, appWidgetIds)

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) =
        refresh(context, appWidgetManager, intArrayOf(appWidgetId))
}

class TimeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Widgets.updateAll(context)
    }
}

object Widgets {
    private val CLASSES = listOf(
        Weather2x1::class.java, Weather2x2::class.java, Weather4x2::class.java,
        Health2x1::class.java, Health2x2::class.java, Health4x2::class.java,
        Calendar2x1::class.java, Calendar2x2::class.java, Calendar4x2::class.java
    )

    fun updateAll(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        for (cls in CLASSES) {
            val ids = m.getAppWidgetIds(ComponentName(c, cls))
            if (ids.isNotEmpty()) {
                c.sendBroadcast(
                    Intent(c, cls).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                )
            }
        }
    }
}

object Builders {
    private fun rv(c: Context, layout: Int) = RemoteViews(c.packageName, layout)

    private fun open(c: Context, pkg: String, code: Int): PendingIntent {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: Intent(c, SettingsActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Square 2x2 mode: transparent widget (no blur) with a centered rounded square card. */
    private fun squareBg(c: Context, v: RemoteViews) {
        v.setInt(android.R.id.background, "setBackgroundColor", 0)
        if (Prefs.blur(c)) {
            val a = Prefs.alpha(c)
            Styler.tint(c, v, R.id.sq_card, Color.argb(a, 255, 255, 255), Color.argb(a, 0, 0, 0))
        } else {
            Styler.tint(c, v, R.id.sq_card, 0xFFF2F2F7.toInt(), 0xFF1F2030.toInt())
        }
    }

    // ---------------------------------------------------------------- Weather
    fun weather(c: Context, size: Int): RemoteViews {
        val square = size == 1 && Prefs.square(c)
        val layout = when {
            square -> R.layout.w_weather_2x2s
            size == 0 -> R.layout.w_weather_2x1
            size == 1 -> R.layout.w_weather_2x2
            else -> R.layout.w_weather_4x2
        }
        val v = rv(c, layout)
        val d = Weather.load(c)
        val bg = android.R.id.background
        if (Prefs.weatherGradient(c)) {
            val pal = if (Prefs.weatherColors(c) && d != null) WeatherColors.palette(d.code, d.isDay) else WeatherColors.default(Styler.isDark(c))
            if (square) {
                v.setInt(bg, "setBackgroundColor", 0)
                v.setInt(R.id.sq_card, "setBackgroundColor", 0)
                v.setImageViewBitmap(R.id.wx_bg, WeatherColors.bitmap(pal.first, pal.second, 328, 320, 56f))
            } else {
                v.setInt(bg, "setBackgroundColor", pal.second or 0xFF000000.toInt())
                v.setImageViewBitmap(R.id.wx_bg, WeatherColors.bitmap(pal.first, pal.second, 16, 256, 0f))
            }
            v.setViewVisibility(R.id.wx_bg, View.VISIBLE)
        } else {
            if (square) squareBg(c, v) else Styler.background(c, v, "weather")
            v.setViewVisibility(R.id.wx_bg, View.GONE)
        }
        Styler.text(
            c, v, "weather",
            intArrayOf(R.id.wx_temp, R.id.wx_cond, R.id.wx_hilo, R.id.wx_desc) + Ids.F_HI + Ids.F_LO,
            intArrayOf(R.id.wx_city) + Ids.F_DAY
        )
        Styler.icon(c, v, R.id.wx_pin, "weather")
        val white = Prefs.weatherGradient(c)
        for (i in 0..2) {
            Styler.color(c, v, Ids.DIV[i], "setBackgroundColor", if (white) 0x4DFFFFFF else 0x26000000, 0x4DFFFFFF)
        }
        if (d == null) {
            v.setTextViewText(R.id.wx_temp, "--°")
            v.setTextViewText(R.id.wx_cond, "")
            v.setTextViewText(R.id.wx_hilo, "")
            v.setTextViewText(R.id.wx_desc, "")
            v.setTextViewText(R.id.wx_city, "Set city in app")
        } else {
            v.setImageViewResource(R.id.wx_icon, Weather.icon(d.code, d.isDay, d.wind))
            v.setTextViewText(R.id.wx_temp, "${d.temp}°")
            val cond = Weather.label(d.code, d.isDay)
            v.setTextViewText(R.id.wx_cond, if (square) cond.lowercase().replaceFirstChar { it.uppercase() } else cond)
            v.setTextViewText(R.id.wx_hilo, "↑${d.hi}° / ↓${d.lo}°")
            v.setTextViewText(R.id.wx_desc, d.summary)
            v.setTextViewText(R.id.wx_city, d.city)
            if (size == 2) {
                for (i in 0..3) {
                    val day = d.days.getOrNull(i) ?: continue
                    v.setTextViewText(Ids.F_DAY[i], day.label)
                    v.setImageViewResource(Ids.F_I1[i], Weather.icon(day.code, true))
                    v.setImageViewResource(Ids.F_I2[i], Weather.icon(day.code, false))
                    v.setTextViewText(Ids.F_HI[i], "${day.hi}°")
                    v.setTextViewText(Ids.F_LO[i], "${day.lo}°")
                }
            }
        }
        v.setOnClickPendingIntent(android.R.id.background, open(c, "com.sec.android.daemonapp", 10 + size))
        return v
    }

    // ---------------------------------------------------------------- Health
    fun health(c: Context, size: Int): RemoteViews {
        val square = size == 1 && Prefs.square(c)
        val layout = when {
            square -> R.layout.w_health_2x2s
            size == 0 -> R.layout.w_health_2x1
            size == 1 -> R.layout.w_health_2x2
            else -> R.layout.w_health_4x2
        }
        val v = rv(c, layout)
        val week = HealthData.week(c)
        val today = LocalDate.now()
        val t = week.firstOrNull { it.date == today } ?: week[0]
        val gs = Prefs.goalSteps(c).toFloat()
        val gm = Prefs.goalMins(c).toFloat()
        val gk = Prefs.goalKcal(c).toFloat()
        if (square) squareBg(c, v) else Styler.background(c, v, "health")
        Styler.text(
            c, v, "health",
            intArrayOf(R.id.h_steps, R.id.h_mins, R.id.h_kcal),
            intArrayOf(R.id.h_steps_g, R.id.h_mins_g, R.id.h_kcal_g)
        )
        val nf = NumberFormat.getIntegerInstance(Locale.US)
        val sz = when (size) { 0 -> 300; 1 -> 400; else -> 360 }
        v.setImageViewBitmap(R.id.h_heart, Hearts.rings(sz, t.steps / gs, t.mins / gm, t.kcal / gk))
        v.setTextViewText(R.id.h_steps, nf.format(t.steps))
        v.setTextViewText(R.id.h_mins, t.mins.toString())
        v.setTextViewText(R.id.h_kcal, t.kcal.toString())
        v.setTextViewText(R.id.h_steps_g, "/" + nf.format(Prefs.goalSteps(c)))
        v.setTextViewText(R.id.h_mins_g, "/" + Prefs.goalMins(c) + " mins")
        v.setTextViewText(R.id.h_kcal_g, "/" + Prefs.goalKcal(c) + " kcal")
        if (size == 2) {
            for (i in 0..6) {
                val d = week[i]
                v.setImageViewBitmap(Ids.HD_IMG[i], Hearts.rings(150, d.steps / gs, d.mins / gm, d.kcal / gk))
                val sunday = d.date.dayOfWeek.value == 7
                val isToday = d.date == today
                if (isToday) {
                    val pat = android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "Md")
                    val txt = android.text.SpannableString(SimpleDateFormat(pat, Locale.getDefault()).format(Date()))
                    txt.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, txt.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    v.setTextViewText(Ids.HD_LBL[i], txt)
                } else {
                    v.setTextViewText(Ids.HD_LBL[i], d.date.dayOfMonth.toString())
                }
                val lt = if (sunday) 0xFFE5484D.toInt() else if (isToday) Styler.MAIN_L else Styler.SUB_L
                val dk = if (sunday) 0xFFC4574F.toInt() else if (isToday) Styler.MAIN_D else Styler.SUB_D
                Styler.color(c, v, Ids.HD_LBL[i], "setTextColor", lt, dk)
            }
        }
        v.setOnClickPendingIntent(android.R.id.background, open(c, "com.sec.android.app.shealth", 20 + size))
        return v
    }

    // ---------------------------------------------------------------- Calendar
    private val GRAY_L = 0xFF9A9AA0.toInt()
    private val GRAY_D = 0xFF8A8A92.toInt()

    fun calendar(c: Context, size: Int): RemoteViews {
        val square = size == 1 && Prefs.square(c)
        val ym = YearMonth.now()
        val ws = Prefs.weekStart(c)
        val startCol = ((ym.atDay(1).dayOfWeek.value % 7) - ws + 7) % 7
        val len = ym.lengthOfMonth()
        val weeks = (startCol + len + 6) / 7
        val layout = when {
            size == 0 -> R.layout.w_calendar_2x1
            square -> R.layout.w_calendar_2x2s
            size == 1 && weeks >= 6 -> R.layout.w_calendar_2x2_6
            size == 1 -> R.layout.w_calendar_2x2
            else -> R.layout.w_calendar_4x2
        }
        val v = rv(c, layout)
        if (square) squareBg(c, v) else Styler.background(c, v, "calendar")
        val now = LocalDate.now()
        val en = Locale.ENGLISH
        when (size) {
            0 -> {
                Styler.text(c, v, "calendar", intArrayOf(R.id.cal_day, R.id.cal_month, R.id.cal_wd), intArrayOf())
                Styler.tint(c, v, R.id.cal_circle, 0xFFE5E5EA.toInt(), 0xFF3A3A3C.toInt())
                v.setTextViewText(R.id.cal_day, now.dayOfMonth.toString())
                v.setTextViewText(R.id.cal_month, SimpleDateFormat("MMM", en).format(Date()).uppercase(en))
                v.setTextViewText(R.id.cal_wd, SimpleDateFormat("EEEE", en).format(Date()))
            }
            1 -> {
                Styler.text(c, v, "calendar", intArrayOf(R.id.cal_month), intArrayOf())
                val fmt = if (square) "MMMM" else "MMM"
                v.setTextViewText(R.id.cal_month, SimpleDateFormat(fmt, en).format(Date()).uppercase(en))
                val letters = arrayOf("S", "M", "T", "W", "T", "F", "S")
                // text color for a weekday index (0 = Sunday .. 6 = Saturday)
                fun dayColor(id: Int, dow: Int) {
                    if (square) {
                        if (dow == 0 || dow == 6) Styler.color(c, v, id, "setTextColor", GRAY_L, GRAY_D)
                        else Styler.color(c, v, id, "setTextColor", Styler.MAIN_L, Styler.MAIN_D)
                    } else {
                        when (dow) {
                            5 -> Styler.color(c, v, id, "setTextColor", 0xFF0A74C9.toInt(), 0xFF5AA9FF.toInt())
                            6 -> Styler.color(c, v, id, "setTextColor", 0xFFD93025.toInt(), 0xFFFF6B6B.toInt())
                            else -> Styler.color(c, v, id, "setTextColor", Styler.MAIN_L, Styler.MAIN_D)
                        }
                    }
                }
                for (i in 0..6) {
                    val dow = (i + ws) % 7
                    v.setTextViewText(Ids.CAL_H[i], letters[dow])
                    dayColor(Ids.CAL_H[i], dow)
                }
                for (r in 0..5) {
                    v.setViewVisibility(Ids.ROWS[r], if (r < weeks) View.VISIBLE else View.INVISIBLE)
                }
                for (i in 0 until 42) {
                    val dn = i - startCol + 1
                    val id = Ids.CELLS[i]
                    if (dn in 1..len) {
                        v.setTextViewText(id, dn.toString())
                        val dow = (i % 7 + ws) % 7
                        if (dn == now.dayOfMonth) {
                            v.setInt(id, "setBackgroundResource", if (square) R.drawable.today_bg else R.drawable.today_sq)
                            Styler.tint(c, v, id, Styler.MAIN_L, Styler.MAIN_D)
                            Styler.color(c, v, id, "setTextColor", Styler.MAIN_D, Styler.MAIN_L)
                        } else {
                            dayColor(id, dow)
                        }
                    } else {
                        v.setTextViewText(id, "")
                    }
                }
            }
            else -> {
                Styler.text(c, v, "calendar", intArrayOf(R.id.cal_title) + Ids.EV_TITLE, intArrayOf(R.id.cal_plus) + Ids.EV_TIME)
                v.setTextViewText(R.id.cal_title, "Today, " + SimpleDateFormat("EEE, MMM d", en).format(Date()))
                val evs = CalendarData.today(c)
                val tf = SimpleDateFormat("h:mma", en)
                for (i in 0..2) {
                    val e = evs.getOrNull(i)
                    if (e == null) {
                        v.setViewVisibility(Ids.EV_BAR[i], View.INVISIBLE)
                        v.setTextViewText(Ids.EV_TIME[i], "")
                        v.setTextViewText(Ids.EV_TITLE[i], if (i == 0) (if (CalendarData.hasPermission(c)) "No events" else "Allow calendar in app") else "")
                    } else {
                        v.setViewVisibility(Ids.EV_BAR[i], View.VISIBLE)
                        v.setInt(Ids.EV_BAR[i], "setBackgroundColor", e.color)
                        v.setTextViewText(Ids.EV_TIME[i], if (e.allDay) "All day" else tf.format(Date(e.begin)))
                        v.setTextViewText(Ids.EV_TITLE[i], e.title)
                    }
                }
                val ins = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                v.setOnClickPendingIntent(
                    R.id.cal_plus,
                    PendingIntent.getActivity(c, 39, ins, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                )
            }
        }
        v.setOnClickPendingIntent(android.R.id.background, open(c, "com.samsung.android.calendar", 30 + size))
        return v
    }
}
