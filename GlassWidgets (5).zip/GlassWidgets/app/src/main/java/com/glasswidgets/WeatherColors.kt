package com.glasswidgets

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader

object WeatherColors {
    private fun p(a: Int, b: Int, c: Int, d: Int, e: Int, f: Int) = Pair(Color.rgb(a, b, c), Color.rgb(d, e, f))

    /** Top/bottom gradient colors by weather, sampled from the Samsung widgets. */
    fun palette(code: Int, day: Boolean): Pair<Int, Int> {
        if (!day) {
            return when (code) {
                in 51..67, in 80..82, in 71..77, in 85..86 -> p(30, 40, 72, 58, 68, 98)
                95, 96, 99 -> p(28, 28, 58, 60, 54, 90)
                else -> p(22, 40, 90, 44, 68, 112)
            }
        }
        return when (code) {
            0, 1 -> p(70, 163, 252, 33, 130, 211)
            2 -> p(49, 106, 183, 86, 139, 183)
            3 -> p(48, 85, 138, 105, 115, 151)
            45, 48 -> p(84, 104, 130, 130, 146, 165)
            in 51..67, in 80..82 -> p(41, 50, 91, 77, 85, 131)
            in 71..77, in 85..86 -> p(96, 122, 164, 152, 172, 202)
            95, 96, 99 -> p(40, 40, 75, 80, 70, 110)
            else -> p(49, 106, 183, 86, 139, 183)
        }
    }

    fun default(dark: Boolean): Pair<Int, Int> =
        if (dark) p(27, 47, 85, 45, 76, 128) else p(63, 134, 224, 88, 163, 234)

    fun bitmap(top: Int, bottom: Int, w: Int, h: Int, radius: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        if (radius > 0f) cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), radius, radius, paint)
        else cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        return bmp
    }
}
